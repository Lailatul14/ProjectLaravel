<?php $__env->startSection('konten'); ?>
<!-- Trigger the modal with a button -->
<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
<div class="col-sm-4">
    <h2 class="page-header">Form Upload Gambar</h2>
      <form action="prosesupload.php" method="POST" enctype="multipart/form-data">
        <div class="form-group">
          <label>Gambar</label><br>
          <input type="file" class="form-control" name="foto">
          <br>
          <button class="btn btn-warning" type="submit">Upload</button>
        </div>  
      </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mencobaLaravel\resources\views/Master/Product/destroy.blade.php ENDPATH**/ ?>