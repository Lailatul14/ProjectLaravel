<?php $__env->startSection('konten'); ?>
<body>

<center >
    <img src="img/gerak.gif" width="500px">
<h1><font color=" #B0E0E6">L'store</h1></font>
</center>
</body>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mencobaLaravel\resources\views/admin/body.blade.php ENDPATH**/ ?>