<!DOCTYPE html>
<html>
<head>
	<title>Menampilkan data dari database</title>
	<link rel="stylesheet" type="text/css" href="style_pbd.css">
</head>
<body>
	
 <center>
<h3>Categories</h3>
	 <form action="input-aksi.php" method="post" onSubmit="validasi()">		
		<table>
			<tr>
				<td>Id Categories</td>
				<td><input type="text" name="ID_ADMIN"></td>					
			</tr>
			<tr>
				<td>Nama categories</td>
				<td><input type="text" name="NAMA_ADMIN"></td>					
			</tr>	
			
			<tr>
				<td></td>
				<td><input type="submit" class="button" value="Simpan" ></td>					
			</tr>				
		</table>
	</form>
	</center>
</body>
	<script>
		function hanyaAngka(evt) {
		  var charCode = (evt.which) ? evt.which : event.keyCode
		   if (charCode > 31 && (charCode < 48 || charCode > 57))
 
		    return false;
		  return true;
		}
	</script>

	</script>
	
	
</html><?php /**PATH C:\xampp\htdocs\mencobaLaravel\resources\views/Master/create.blade.php ENDPATH**/ ?>