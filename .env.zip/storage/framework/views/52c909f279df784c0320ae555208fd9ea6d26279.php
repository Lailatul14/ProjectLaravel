<?php $__env->startSection('konten'); ?>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<div class="breadcome-list">
<div class="row">
<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
<div class="breadcomb-wp">
<div class="breadcomb-icon">
<i class="icon nalika-home"></i>
</div>
<div class="breadcomb-ctn">
<h2>User List</h2>
<p>Welcome to L'store <span class="bread-ntd"><br>#
eat for life</span></p>

</div>
</div>
</div>
<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
<div class="breadcomb-report">
<button data-toggle="tooltip" data-placement="left" title="" class="btn" data-original-title="Download Report"><i class="icon nalika-download"></i></button>
</div>
</div>
</div>
</div>
</div>
<div class="product-status mg-b-30">
<div class="container-fluid">
<div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="product-status-wrap">
                            <h4>User List</h4>
                            <div class="add-product">
                                <a href="Usercreate"> Add user</a>
                             </div>
                            <table >
                              <thead>
                                    <th>User ID</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Password</th>
                                    <th>Job Status</th>
                                    <th>Edit Data</th>
                                </tr>
                                 
                                 </thead>
                              <tbody>
                                
                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                  
                                   
                                   <td><?php echo e($us->USER_ID); ?></td>
                                   <td><?php echo e($us->FIRST_NAME); ?></td>
                                   <td><?php echo e($us->LAST_NAME); ?></td>
                                   <td><?php echo e($us->EMAIL); ?></td>
                                   <td><?php echo e($us->PHONE); ?></td>
                                   <td><?php echo e($us->PASSWORD); ?></td>
                                   <td><tabel class="label <?php echo e(($us->JOB_STATUS == 1) ? 'label-primary' : 'label-danger'); ?>"><?php echo e(($us->JOB_STATUS == 1) ? 'Active' : 'Non-Active'); ?></tabel></td>
                                  
                                    
                                    <td>

                                        <a href="Useredit<?php echo e($us->USER_ID); ?>">
                                          <button data-toggle="tooltip" title="" class="pd-setting-ed" data-original-title="Edit"></li>
                                            <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                          </button>
                                        </a>
                                         

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </tbody>
                                    </table>
                                       


                     

                <div class="custom-pagination">
                <ul class="pagination">
                  <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                  <li class="page-item"><a class="page-link" href="#">1</a></li>
                  <li class="page-item"><a class="page-link" href="#">2</a></li>
                  <li class="page-item"><a class="page-link" href="#">3</a></li>
                  <li class="page-item"><a class="page-link" href="#">Next</a></li>
                </ul>
                            </div>
                        </div>
                    </div>
            </div>
          </div>
        </div>

        
            <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mencobaLaravel\resources\views/Master/User/index.blade.php ENDPATH**/ ?>