@extends('admin/admin')
@section('konten')
<body>

<center >
    <img src="img/gerak.gif" width="500px">
<h1><font color=" #B0E0E6">L'store</h1></font>
</center>
</body>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
@endsection