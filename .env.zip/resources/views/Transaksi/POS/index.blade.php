@extends('admin/admin')
@section('konten')
<div class="breadcome-area">
<div class="container-fluid">
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<div class="breadcome-list">
<div class="row">
<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
<div class="breadcomb-wp">
<div class="breadcomb-icon">
<i class="icon nalika-home"></i>
</div>
<div class="breadcomb-ctn">
<h2>Point Of Sales</h2>
<p>Welcome to L"store <span class="bread-ntd">#eatForLife</span></p>
</div>
</div>
</div>
<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
<div class="breadcomb-report">
<button data-toggle="tooltip" data-placement="left" title="" class="btn" data-original-title="Download Report"><i class="icon nalika-download"></i></button>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
 </div>
 <div class="single-product-tab-area mg-b-30">

<div class="single-pro-review-area">
<div class="container-fluid">
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<div class="review-tab-pro-inner">

<div id="myTabContent" class="tab-content custom-product-edit">
<div class="product-tab-list tab-pane fade active in" id="description">
<div class="row">
<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
<div class="review-content-section">

                                                  <div class="input-group mg-b-pro-edt">
                                                        <span class="input-group-addon"><i class="icon nalika-like" aria-hidden="true"></i></span>
                                                        <input type="text" disabled="" class="form-control" placeholder="Category_ID">
                                                      
                                                    </div>
                                                    </div>
                                                </div>
                                                                                 


<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
<div class="review-content-section">
<select name="" class="form-control pro-edt-select form-control-primary">
@foreach ($categories as $cat)                    
                      <option value=" { $cat->CATEGORY_ID }}">
                        {{ $cat->CATEGORY_NAME }}
                      </option>
                      @endforeach

</select>
<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
<div class="breadcomb-report">

</div>
</div>
</div>
</div>
</div>
<div class="product-status mg-b-30">
<div class="container-fluid">
<div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="product-status-wrap">
                           
                            <table>
                                <tbody><tr>
                                    <th>ID</th>
                                    <th>Product_Name</th>
                                    <th>Jumlah</th>
                                    <th>Price</th>
                                    <th>Sub Total</th>
                                    
                                </tr>
                                 
                                <tr> 
                                    <td>1</td>
                                    <td>Fried Rice</td>
                                    <td><input type="number" width="20px" class="mr-sm-3 form-control"></td>
                                    <td>Rp. 15.000</td>
                                    <td> Rp. 25.000</td>
                                    
                                    
                                     <td>
                                        <a href="Customeredit"><button data-toggle="tooltip" title="" class="pd-setting-ed" data-original-title="Edit"></li><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>
                                        </a>
                                          
                                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalLong" class="pd-setting-ed" data-original-title="Trash"><i class="fa fa-trash-o" aria-hidden="true"></i></button>

                                        <!-- Modal -->
                                                <div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                                                  <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                      <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLongTitle"><p class="text-primary">DELETE CATEGORY DATA</p></h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                          <span aria-hidden="true">&times;</span>
                                                        </button>
                                                      </div>
                                                      <div class="modal-body">
                                                         <h5><p class="text-primary">Are You Sure To Delete This Data?</p></h5> 
                                                      </div>
                                                      
                                                      <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                                                        <button type="button" class="btn btn-primary">Yes</button>
                                                      </div>

                                                    </div>
                                                  </div>
                                                </div>
                                            <!-- /Modal -->

                                    </td>
                                </tr>

                           <tr> 
                                    <td>2</td>
                                    <td>Potato</td>
                                    <td><input type="number" width="20px" class="mr-sm-3 form-control"></td>
                                    <td>Rp. 10.000</td>
                                    <td> Rp. 10.000</td>
                                   
                                     <td>
                                        <a href="Customeredit"><button data-toggle="tooltip" title="" class="pd-setting-ed" data-original-title="Edit"></li><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>
                                        </a>
                                         
                                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalLong" class="pd-setting-ed" data-original-title="Trash"><i class="fa fa-trash-o" aria-hidden="true"></i></button>

                                        <!-- Modal -->
                                                <div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                                                  <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                      <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLongTitle"><p class="text-primary">DELETE CATEGORY DATA</p></h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                          <span aria-hidden="true">&times;</span>
                                                        </button>
                                                      </div>
                                                      <div class="modal-body">
                                                         <h5><p class="text-primary">Are You Sure To Delete This Data?</p></h5> 
                                                      </div>
                                                      
                                                      <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                        <button type="button" class="btn btn-primary">Save changes</button>
                                                      </div>

                                                    </div>
                                                  </div>
                                                </div>
                                            <!-- /Modal -->

                                    </td>
                                </tr>
                                
                           
                             </tbody></table>
                  
                        </div>
                    </div>
                </div>
            </div>
        </div>
<form>
  <div class="form-group row">
    <label for="colFormLabelSm" class="col-sm-2 col-form-label col-form-label-sm"><font color="#00FFFF">Pajak (10%)  </font></label>
    <div class="col-sm-10">
      <input type="email" class="form-control form-control-sm" id="colFormLabelSm" placeholder="Rp. ">
    </div>
  </div>
  <div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label"><font color="#00FFFF">Discount</font></label>
    <div class="col-sm-10">
      <input type="email" class="form-control" id="colFormLabel" placeholder="Rp. ">
    </div>
  </div>
  <div class="form-group row">
    <label for="colFormLabelLg" class="col-sm-2 col-form-label col-form-label-lg"><font color="#00FFFF">Total</font></label>
    <div class="col-sm-10">
      <input type="email" class="form-control form-control-lg" id="colFormLabelLg" placeholder="Rp. ">
    </div>

  </div>
  </div>
</form>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>


@endsection