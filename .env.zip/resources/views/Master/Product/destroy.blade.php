@if($cat ->CATEGORY_STATUS == 0)
	{{  $cat ->CATEGORY_NAME}}
	@endif